import json
from datetime import datetime

from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi


def get_proxy():
    file = open("settings.json", 'r')
    settings = json.load(file)

    print(settings.get("proxy"))
    return settings.get("proxy")


# https://endway.su/@niggabyte/