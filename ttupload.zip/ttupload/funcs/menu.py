def display_menu():
    print("\nВыберите действие:")
    print("[1] Аккаунты")
    print("[2] Настройки")
    print("[3] Загрузить видео")
    print("[4] Авто загрузка видео")
    print("[0] Выход")


def display_accounts_menu():
    print("\nМеню аккаунтов:")
    print("[1] Список аккаунтов")
    print("[2] Добавить новый аккаунт")
    print("[3] Удалить аккаунт")
    print("[4] Настроить аккаунт(описание видео, теги)")
    print("[0] Назад")

# https://endway.su/@niggabyte/