import os
import json
import time
import random


from funcs.Tiktok_uploader import uploadVideo

from funcs.bd_funcs import get_proxy
from funcs.menu import display_menu, display_accounts_menu


def check_and_execute_upload(settings_file):
    try:
        print("\nАвтоматическая загрузка видео началась!\n"
              "Чтобы закончить это действие нажмите 'CTRL + C'")
        while True:
            with open(settings_file, 'r') as f:
                settings = json.load(f)

            current_time = time.strftime('%H:%M')
            videos_folder = settings.get("videos_folder")

            for account in settings.get('accounts', []):
                auto_upload_time = account.get('auto_upload')

                if auto_upload_time == "1":
                    continue

                if current_time == auto_upload_time:
                    
                    account_name = account["name"]
                    title = account["title"]
                    tags = account["tags"]
                    session_id = account["session_id"]
                    proxy = get_proxy()

                    if proxy != '1': # https://endway.su/@niggabyte/
                        proxies = {
                            "http":f"http://{proxy}"
                        }
                    else:
                        proxies = '1'

                    # Выбираем случайное видео из папки videos_folder
                    video_files = [f for f in os.listdir(videos_folder) if f.endswith('.mp4')]
                    if video_files:
                        random_video = random.choice(video_files)
                        video_path = f"{videos_folder}{random_video}"
                        
                        print(f"Выбранное видео: {video_path}")
                        try:
                            uploadVideo(session_id=session_id,
                                        video=video_path,
                                        title=title,
                                        tags=tags,
                                        proxy=proxies)
                            os.remove(video_path)

                        except Exception as ex:
                            print(f'Произошла ошибка при публикации видео: {ex}')
                    else:
                        print("В папке videos_folder нет MP4 видео")
                    
            time.sleep(60)
    except KeyboardInterrupt:
        return


def get_video_and_account_data(settings_file):
    try:
        file = open(settings_file, 'r')
        settings = json.load(file)

        videos_folder = settings.get("videos_folder", "videos/")
        accounts = settings.get("accounts", [])
        proxy = get_proxy()

        if proxy != '1':
            proxies = {
                "http":f"http://{proxy}"
            }
        else:
            proxies = '1'

        print("Список доступных видео:")
        for video_file in os.listdir(videos_folder):
            print(video_file)

        selected_video = input("Введите имя файла видео, которое вы хотите выбрать(чтобы загрузить все видео напишите "
                               "0): ")
        selected_account = None

        print("Список доступных аккаунтов:")
        for i, account in enumerate(accounts):
            print(f"{i + 1}. {account['name']}")

        while True:
            try:
                account_choice = int(input("Выберите номер аккаунта: ")) - 1
                if 0 <= account_choice < len(accounts):
                    selected_account = accounts[account_choice]
                    break
                else:
                    print("Некорректный выбор аккаунта. Попробуйте снова.")
            except ValueError:
                print("Введите число.")

        video_path = os.path.join(videos_folder, selected_video)
        session_id = selected_account.get("session_id")
        title = selected_account.get("title")
        tags = selected_account.get("tags").split(",")

        result = {
            "video_path": video_path,
            "session_id": session_id,
            "title": title,
            "tags": tags
        }

        if selected_video == '0': # https://endway.su/@niggabyte/
            video_list = os.listdir(videos_folder)
            for video in video_list:
                try:
                    uploadVideo(session_id=session_id, video=videos_folder + video, title=title, tags=tags, proxy=proxies) 
                    os.remove(os.path.join(videos_folder, video)) 
                except Exception as ex:
                    print(ex)
            return result
        
        uploadVideo(session_id=session_id, video=video_path, title=title, tags=tags, proxy=proxies)
        os.remove(video_path) 

        return result
  
    except FileNotFoundError:
        print(f"Файл {settings_file} не найден.")
        return None
    except KeyboardInterrupt:
        return
    except Exception as ex:
        print(ex)


def edit_settings(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)

            print("Текущие настройки:\n"
            f"Папка с видео: {data.get('videos_folder')}\n"
            f"Прокси: {data.get('proxy')}\n")

            print("Настройки:")
            print("[1] Изменить/добавить папку из которой берутся видео")
            print("[2] Изменить/добавить прокси")
            print("[0] Выйти в главное меню")

            settings_choice = input("Введите номер действия (0-2): ")

            if settings_choice == "1":
                new_videos_folder = input("Введите новую папку для видео: ")
                data["videos_folder"] = new_videos_folder
                print("Папка для видео успешно изменена.")
            elif settings_choice == "2":
                print("\nПример: 179.108.169.7:8080")
                new_proxy = input("Введите прокси (HTTP): ") # https://endway.su/@niggabyte/
                data["proxy"] = new_proxy
            elif settings_choice == "0":
                print("Возврат в главное меню.")
            else:
                print("Неверный выбор. Пожалуйста, введите номер действия от 0 до 2.")

            with open(file_path, 'w') as file:
                json.dump(data, file, indent=4)
    except FileNotFoundError:
        print(f"Файл {file_path} не найден.")
    except KeyboardInterrupt:
        return


def start_func(file_path):
    clear_console()
    # Проверяем, существует ли файл
    if not os.path.exists(file_path):
        # Если файл не существует, создаем его и добавляем начальные поля
        settings = {
            "private_key": "",
            "videos_folder": "",
            "accounts": [],
            "proxy":"1"
        }

        with open(file_path, 'w') as file:
            json.dump(settings, file, indent=4)

        print(f"Файл {file_path} был создан с начальными полями.")
    else:
        print(f"Файл {file_path} уже существует.")

        with open("settings.json", 'r') as f:
            settings = json.load(f)


def edit_account(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
            accounts = data.get("accounts", [])
            if not accounts:
                print("Список аккаунтов пуст.")
                return

            list_accounts(file_path)  # Вывести список аккаунтов с номерами

            account_num = input("Введите номер аккаунта для редактирования (0 для отмены): ")

            if account_num == "0":
                print("Отменено.")
                return

            account_num = int(account_num)
            if 1 <= account_num <= len(accounts):
                selected_account = accounts[account_num - 1] # https://endway.su/@niggabyte/

                print(f"\nРедактирование аккаунта '{selected_account['name']}':")
                print("[1] Изменить описание к видео")
                print("[2] Изменить теги к видео")
                print("[0] Возврат в предыдущее меню")

                edit_choice = input("Введите номер действия (0-2): ")

                if edit_choice == "1":
                    new_description = input("Введите новое описание к видео: ")
                    selected_account["title"] = new_description
                    print("Описание к видео успешно изменено.")
                elif edit_choice == "2":
                    new_tags = input("Введите новые теги к видео(через запятую например - fyp, viral): ")
                    selected_account["tags"] = new_tags
                    print("Теги к видео успешно изменены.")
                elif edit_choice == "0":
                    print("Возврат в предыдущее меню.")
                else:
                    print("Неверный выбор. Пожалуйста, введите номер действия от 0 до 2.")

                with open(file_path, 'w') as file:
                    json.dump(data, file, indent=4)
            else:
                print("Неверный номер аккаунта.")
    except FileNotFoundError:
        print(f"Файл {file_path} не найден.")
    except KeyboardInterrupt:
        return


def list_accounts(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
            accounts = data.get("accounts", [])
            if not accounts:
                print("\n\nСписок аккаунтов пуст.")
            else:
                print("\n\nСписок аккаунтов:")
                for i, account in enumerate(accounts, start=1):
                    print(f"{i}. Аккаунт: {account['name']}")
                    print(f"   Токен: {account['session_id']}")
                    print(f"   Описание: {account['title']}")
                    print(f"   Теги: {account['tags']}")
                    print("\n")
    except FileNotFoundError:
        print(f"Файл {file_path} не найден.")
    except KeyboardInterrupt:
        return


def delete_account(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
            accounts = data.get("accounts", [])
            if not accounts:
                print("Список аккаунтов пуст.")
                return

            list_accounts(file_path)  # Вывести список аккаунтов с номерами

            account_num = input("Введите номер аккаунта для удаления (0 для отмены): ")

            if account_num == "0":
                print("Отменено.") # https://endway.su/@niggabyte/
                return

            account_num = int(account_num)
            if 1 <= account_num <= len(accounts):
                deleted_account = accounts.pop(account_num - 1)

                with open(file_path, 'w') as file:
                    data["accounts"] = accounts
                    json.dump(data, file, indent=4)

                print(f"Аккаунт '{deleted_account['name']}' успешно удален.")
            else:
                print("Неверный номер аккаунта.")
    except FileNotFoundError:
        print(f"Файл {file_path} не найден.")
    except KeyboardInterrupt:
        return


def add_account(file_path):
    session_id = input("Введите session_id: ")
    account_name = input("Введите название аккаунта: ")

    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
            accounts = data.get("accounts", [])
            new_account = {"name": account_name, "session_id": session_id, "title": "my title",
                           'tags': "fyp, viral", "auto_upload": "1"}
            accounts.append(new_account)

        with open(file_path, 'w') as file:
            data["accounts"] = accounts
            json.dump(data, file, indent=4)

        print(f"Аккаунт '{account_name}' успешно добавлен.")
    except FileNotFoundError:
        print(f"Файл {file_path} не найден.")
    except KeyboardInterrupt:
        return


def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')


def main():
    file_path = "settings.json"
    start_answer = start_func(file_path)
    
    while True:
        # clear_console()
        display_menu()
        choice = input("Введите номер действия (0-3): ")

        if choice == "1":
            clear_console()
            print("\n\nВы выбрали 'Аккаунты'.\n")
            while True:
                display_accounts_menu()
                account_choice = input("Введите номер действия (0-3): ")

                if account_choice == "1":
                    clear_console()
                    list_accounts(file_path) # https://endway.su/@niggabyte/
                elif account_choice == "2":
                    clear_console()
                    add_account(file_path)
                elif account_choice == "3":
                    clear_console()
                    delete_account(file_path)
                elif account_choice == "4":
                    clear_console()
                    edit_account(file_path)
                elif account_choice == "0":
                    print("Возврат в предыдущее меню.")
                    clear_console()
                    break
                else:
                    print("Неверный выбор. Пожалуйста, введите номер действия от 0 до 3.")

        elif choice == "2":
            clear_console()
            print("\n\nВы выбрали 'Настройки'.")
            edit_settings(file_path)
        elif choice == "3":
            clear_console()
            print("\n\nВы выбрали 'Загрузить видео'.")
            print(get_video_and_account_data(file_path))
        elif choice == "4":
            check_and_execute_upload("settings.json")
        elif choice == "0":
            print("Выход из программы.")
            break
        else:
            print("Неверный выбор. Пожалуйста, введите номер действия от 0 до 3.")


if __name__ == "__main__":
    main()
